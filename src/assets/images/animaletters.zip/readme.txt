This font was created by http://www.peax-webdesign.com 
------------------------------------------------------
You can use it for free for your personnal and commercial projects if you credit my website, "like" me on Facebook or give a Google +1 to my profile https://plus.google.com/103595703505477716588
------------------------------------------------------
Enjoy !